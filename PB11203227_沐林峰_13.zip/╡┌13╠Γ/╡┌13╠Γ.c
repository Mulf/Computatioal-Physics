#include<stdio.h>
#include<math.h>
#include<time.h>
#include "random.h"     //16807随机数产生器
#define delta 3.15
#define sigmax 1
#define sigmay 1
#define M 1            //粒子数
#define belta 1
#define num 1E5         //所要走的步数
main()
{
    int seed=time(0);
    double Xnx=random(seed),Xny=random(seed),Xtx,Xty,sumx2,sumy2,sumxy2;   //定义一些需要用的变量
    double p(double x,double y);
    FILE *fp;
    fp=fopen("13.txt","w");      //记录数据的文件
    int i,j;
    sumx2=sumy2=sumxy2;
    for(i=0;i<num;)
    {

            double ksix,ksiy;
            ksix=random(seed);     //产生随机数
            ksiy=random(seed);     //产生随机数
            double stepx,stepy;
            stepx=(ksix-0.5)*delta;   //粒子在x方向移动的步长
            stepy=(ksiy-0.5)*delta;   //粒子在y方向移动的步长
            Xtx=Xnx+stepx;            //试探移动粒子
            Xty=Xny+stepy;
            double r;
            r=p(Xtx,Xty)/p(Xnx,Xny);   //计算判断量r
            if(r>1)                    //如果r>1，则该步可以走
            {
                Xnx=Xtx;               //移动
                Xny=Xty;               //移动
                fprintf(fp,"%lf\t%lf\n",Xnx,Xny);   //坐标写入文件
                sumx2+=pow(Xnx,2);                  //计算x^2和
                sumy2+=pow(Xny,2);                  //计算y^2和
                sumxy2+=pow(Xnx,2)+pow(Xny,2);      //计算x^2+y^2
                i++;
            }
            else           //r<1的情况
            {
                double rand;     //再产生一个随机数
                rand=random(seed);
                if(rand<r)    //rand<r,则该步可以移动
                {
                    Xnx=Xtx;   //移动
                    Xny=Xty;
                    fprintf(fp,"%lf\t%lf\n",Xnx,Xny); //坐标写入文件
                    sumx2+=pow(Xnx,2);                //计算x^2和
                    sumy2+=pow(Xny,2);                //计算y^2和
                    sumxy2+=pow(Xnx,2)+pow(Xny,2);    //计算x^2+y^2和
                    i++;
                }
            }

    }
    sumx2/=num;             //求<x^2>
    sumy2/=num;             //求<y^2>
    sumxy2/=num;            //求<x^2+y^2>
    printf("<x^2>=%lf,<y^2>=%lf,<x^2+y^2>=%lf",sumx2,sumy2,sumxy2);  //输出结果

}
double p(double x,double y)                //定义计算粒子在(x,y)的函数p(x,y)
{
    double p;
    p=exp(-belta*(pow(x/sigmax,2)+pow(y/sigmay,2))/2);
    return p;

}
