#include<stdio.h>
#include<math.h>
#define l 513
main()
{
    int x,y,i,j;
    FILE *fp,*fp1;
    fp=fopen("11.txt","r");
    fp1=fopen("18_2.txt","w");
    int epsilon;
    for(epsilon=1;epsilon<=l;epsilon*=2)
    {
        int sum,signal,delta;
        delta=512/epsilon;
        sum=signal=0;
        int N[l][l];
        for(i=0;i<l;i++)
        {
            for(j=0;j<l;j++)
            {
                N[i][j]=0;
            }
        }
        while(!feof(fp))
        {
            fscanf(fp,"%d\t%d\n",&x,&y);
            i=(x+256)/delta;
            j=(y+256)/delta;
            N[i][j]=1;
        }
        for(i=0;i<l;i++)
        {
            for(j=0;j<l;j++)
            {
                sum+=N[i][j];
            }
        }
        fprintf(fp1,"%lf\t%lf\n",log(epsilon),log(sum));
        rewind(fp);
    }
}
