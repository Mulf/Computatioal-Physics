#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include<math.h>
main()
{
   FILE *fp;
   fp=fopen("Marsagalia.txt","w");
   int i;
   srand((unsigned)time(NULL));
   double u,v,r,x,y,z,PI=3.1415926;
   for(i=0;i<100000;)
   {
       u=rand()/(double)RAND_MAX;
       u=2*u-1;
       v=rand()/(double)RAND_MAX;
       v=2*v-1;
       r=sqrt(u*u+v*v);
       if(r<1)
       {
           x=2*u*sqrt(1-r*r);
           y=2*v*sqrt(1-r*r);
           z=1-2*r*r;
           i++;
       }
       fprintf(fp,"%1.6lf\t%-1.6lf\t%-1.6lf\n",x,y,z);

   }
   fclose(fp);
   system("pause");

}
