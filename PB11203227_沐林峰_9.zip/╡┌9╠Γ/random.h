#ifndef random_H_INCLUDED
#define random_H_INCLUDED
inline double random(long int seed)
{
    int a,m,q,r,result;
    static int i=0,z;
    if(i==0) z=seed;
    a=16807,m=2147483647;
    q=m/a;
    r=m%a;
    result=a*(z%q)-r*(z/q);
    if(result<0)
    {
         z=result+m;
    }
    else z=result;
    i++;
    return(z/(double)m);
}


#endif // 16807_H_INCLUDED
