#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include<math.h>
main()
{
   FILE *fp;
   fp=fopen("xyz.txt","w");
   int i;
   srand((unsigned)time(NULL));
   double u,v,PI=3.1415926;
   double theta,phi,x,y,z;
   for(i=0;i<10000;i++)
   {
       u=rand()/(double)RAND_MAX;
       u=2*u-1;
       v=rand()/(double)RAND_MAX;
       theta=acos(u);
       phi=v*2*PI;
       x=sin(theta)*cos(phi);
       y=sin(theta)*sin(phi);
       z=cos(theta);
       fprintf(fp,"%1.6lf\t%-1.6lf,%-1.6lf\n",x,y,z);

   }
   fclose(fp);
   system("pause");
}
