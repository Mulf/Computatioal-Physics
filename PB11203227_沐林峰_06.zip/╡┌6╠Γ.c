#include<stdio.h>
#include<time.h>
#include<math.h>
#include<stdlib.h>
main()
{
    srand((unsigned)time(NULL));  //随机数种子
    long int i,j;
    FILE *fp1,*fp2;
    double n,p,sample[111]={0},x2,x[111],xi[111];
     //定义存放能量的数组x[111],yi以及用来统计直接抽样法中抽到不同x[i]的数组sample[111]
fp1=fopen("06problem.txt","r");
for(i=0;i<111;i++)
{
    fscanf(fp1,"%lf\t%lf\n",&x[i],&xi[i]);  //将所给数据写入相应的数组
}
/*直接抽样法*/
for(i=0;i<111;i++)  //18到26行驶把xi[]中的频数转变为概率分布函数，以便直接抽样
{
    if(i>0) xi[i]+=xi[i-1];

}
for(i=0,n=xi[110];i<111;i++)
{
    xi[i]=xi[i]/n;
}
fp1=fopen("6_1.txt","w");
for(i=0;i<1000000;i++)
{
   p=rand()/(double)RAND_MAX;   //产生随机数
   if(p<xi[0]) sample[0]++;
   for(j=1;j<111;j++)
   {
       if(p>=xi[j-1]&&p<=xi[j])   sample[j]++;  //统计不同不同能量被抽到的频数
   }
}
for(j=0;j<111;j++)
   fprintf(fp1,"%lf\t%lf\n",x[j],sample[j]);  //所得结果将写入txt文件，以便与画图
fclose(fp1);
/*舍选抽样法*/
fp1=fopen("06problem.txt","r");  //由于xi[i]有变动，数据重新写入
for(i=0;i<111;i++)
{
    fscanf(fp1,"%lf\t%lf\n",&x[i],&xi[i]);
}
fclose(fp1);
double xi1,xi2,xix,xiy;
double F(double xix),G(double xi1);   //定义F(x),将将随机数0~1转化为区间(2900,3011)上的点的函数G(x)
for(i=0;i<111;i++)    //累加器归0
{
    sample[i]=0;
}
fp2=fopen("6_2.txt","w");
for(i=0,j=0;i<100000;i++)
{
    xi1=rand()/(double)RAND_MAX;   //产生随机数
    xi2=rand()/(double)RAND_MAX;   //产生随机数
    xix=G(xi1);        //将随机数xi1变为区间(2900,3011)上的点xix
    xiy=xi2*F(xix);    //计算xiy
    p=xi[(int)xix-2900];  //xix所对应的P(x)
    if(xiy<p)            //判断所生成的随机点是否符合要求
    {
        sample[(int)xix-2900]++;  //对抽到不同的数量累加
        j++;    //计算抽样效率
    }
}
for(i=0;i<111;i++)
{
    fprintf(fp2,"%lf\t%lf\n",x[i],sample[i]);    //将能量及对应的数量写入文件
}
fclose(fp2);
printf("The efficiency of sampling is:%lf",j/100000.0); //输出抽样效率
}


double F(double xix)  //编辑F(x)
{
    double F;
    if(xix<2995) F=3000;
    else if(xix<3005) F=41000;
    else F=500;
    return(F);
}
double G(double xi1)  //编辑G(x)
{
    double xix;
    if(xi1<285/698.0)  xix=698*xi1/3+2900;
    else if(xi1<695/698.0)  xix=698*(xi1-285/698.0)/41+2995;
    else xix=698*(xi1-695/698.0)/0.5+3005;
    return(xix);
}
